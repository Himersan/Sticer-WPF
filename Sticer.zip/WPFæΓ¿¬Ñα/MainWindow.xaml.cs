﻿using System;
using System.Windows;
using System.Windows.Input;
using System.Windows.Forms;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.IO;

namespace WPFСтикер
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            panel.MouseLeftButtonDown += new MouseButtonEventHandler(StackPanel_MouseLeftButtonDown);
        }

        int IDfile;

        private void ContBt_Checked(object sender, RoutedEventArgs e)
        {
            closer.Visibility = Visibility.Collapsed;
            Font_.Visibility = Visibility.Collapsed;
            Zakrep.Visibility = Visibility.Collapsed;
            Themes_.Visibility = Visibility.Collapsed;
            NameZam.Visibility = Visibility.Collapsed;
            ClearBt.Visibility = Visibility.Collapsed;
            NewZaiska.Visibility = Visibility.Collapsed;
            FileZapiski.Visibility = Visibility.Collapsed;
            ContBt.Content = "+";
            Tb.Focus();
        }

        string Path2;
        string Path1;
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //Содержимое блактнота
            Item1_Selected(sender, e);

            ColorPanel.Visibility = Visibility.Collapsed;
            NamePanel.Visibility = Visibility.Collapsed;
            FileZapiski.Visibility = Visibility.Collapsed;

            TbName.Text = Title;
            Tb.Focus();

            ContBt.IsChecked = false;
        }

        private void StackPanel_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                this.DragMove();
            }
            catch (Exception)
            {
            }
        }

        private void closer_Click(object sender, RoutedEventArgs e)
        {
            SavingFiles();
            Close();
        }

        private void ContBt_Unchecked(object sender, RoutedEventArgs e)
        {
            ContBt.Content = "=";
            closer.Visibility = Visibility.Visible;
            Font_.Visibility = Visibility.Visible;
            Zakrep.Visibility = Visibility.Visible;
            Themes_.Visibility = Visibility.Visible;
            NameZam.Visibility = Visibility.Visible;
            ClearBt.Visibility = Visibility.Visible;
            NewZaiska.Visibility = Visibility.Visible;
            Tb.Focus();
        }

        private void Font_Click(object sender, RoutedEventArgs e)
        {
            FontDialog fontDialog = new FontDialog();
            if(fontDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                Tb.FontFamily = new System.Windows.Media.FontFamily(fontDialog.Font.Name);
                Tb.FontSize = fontDialog.Font.Size * 98.0 / 72.0;
                Tb.FontWeight = fontDialog.Font.Bold ? FontWeights.Bold : FontWeights.Regular;
                Tb.FontStyle = fontDialog.Font.Italic ? FontStyles.Italic : FontStyles.Normal;
            }
            Tb.Focus();
        }

        bool ZakrepNaj = false;
        private void Zakrep_Click(object sender, RoutedEventArgs e)
        {
            if(ZakrepNaj == false)
            {
                Topmost = true;
                ZakrepNaj = true;
                ZakrepPic.Source = BitmapFrame.Create(new Uri(@"pack://application:,,,/Pics/Zakr.png"));
            }
            else
            {
                Topmost = false;
                ZakrepNaj = false;
                ZakrepPic.Source = BitmapFrame.Create(new Uri(@"pack://application:,,,/Pics/Otkrep.png"));
            }
            Tb.Focus();
        }

        bool Colorstouch = false;
        private void Themes_Click(object sender, RoutedEventArgs e)
        {
            if(Colorstouch == false)
            {
                Colorstouch = true;
                ColorPanel.Visibility = Visibility.Visible;
                if (Width == 400)
                    Width += 30;
            }
            else
            {
                Colorstouch = false;
                ColorPanel.Visibility = Visibility.Collapsed;
                if (Width == 440)
                    Width -= 30;
            }
            shirina();
            Tb.Focus();
        }

        int btnColor = 0;
        private void ColorChanger()
        {
            switch (btnColor)
            {
                case 1:
                    {
                        this.Background = (SolidColorBrush)new BrushConverter().ConvertFromString("#FFEEE876");
                        panel.Background = (SolidColorBrush)new BrushConverter().ConvertFromString("#FFEEE411");
                        break;
                    }
                case 2:
                    {
                        this.Background = (SolidColorBrush)new BrushConverter().ConvertFromString("#FF9DF59D");
                        panel.Background = (SolidColorBrush)new BrushConverter().ConvertFromString("#FF4AF04A");
                        break;
                    }
                case 3:
                    {
                        this.Background = (SolidColorBrush)new BrushConverter().ConvertFromString("#FFF5B9F5");
                        panel.Background = (SolidColorBrush)new BrushConverter().ConvertFromString("#FFEE89EE");
                        break;
                    }
                case 4:
                    {
                        this.Background = (SolidColorBrush)new BrushConverter().ConvertFromString("#FF93C3E4");
                        panel.Background = (SolidColorBrush)new BrushConverter().ConvertFromString("#FF68B8F0");
                        break;
                    }
                default:
                    break;
            }
            ColorPanel.Visibility = Visibility.Collapsed;
            Colorstouch = false;
            if (Width == 440)
                Width -= 30;
            Tb.Focus();
        }

        private void Color1_Click(object sender, RoutedEventArgs e)
        {
            btnColor = 1;
            ColorChanger();
        }

        private void Color2_Click(object sender, RoutedEventArgs e)
        {
            btnColor = 2;
            ColorChanger();
        }

        private void Color3_Click(object sender, RoutedEventArgs e)
        {
            btnColor = 3;
            ColorChanger();
        }

        private void Color4_Click(object sender, RoutedEventArgs e)
        {
            btnColor = 4;
            ColorChanger();
        }

        bool NamerPanTch = false;
        private void NameZam_Click(object sender, RoutedEventArgs e)
        {
            if (NamerPanTch == false)
            {
                NamerPanTch = true;
                NamePanel.Visibility = Visibility.Visible;
                if(Width == 400)
                    Width += 30;
            }
            else
            {
                NamerPanTch = false;
                NamePanel.Visibility = Visibility.Collapsed;
                if (Width == 440)
                    Width -= 30;
            }
            shirina();
            TbName.Focus();
        }

        //Изменение ширины окна
        bool widhtht = false;
        private void shirina()
        {
            if (NamerPanTch == true && Colorstouch == true && ZapiskiPanel == true)
            {
                widhtht = true;
                Width += 180;
            }

            if(widhtht == true)
            {
                if (NamerPanTch == false || Colorstouch == false || ZapiskiPanel == false)
                {
                    Width -= 180;
                    widhtht = false;
                }
            }
        }

        private void TbName_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if(e.Key == Key.Enter)
            {
                Title = TbName.Text;
                NameZam_Click(sender,e);
                Tb.Focus();
            }
        }

        private void ClearBt_Click(object sender, RoutedEventArgs e)
        {
            Tb.Text = "";
        }

        bool ZapiskiPanel = false;
        private void NewZaiska_Click(object sender, RoutedEventArgs e)
        {
            if (ZapiskiPanel == false)
            {
                ZapiskiPanel = true;
                FileZapiski.Visibility = Visibility.Visible;
                if (Width == 400)
                    Width += 60;
            }
            else
            {
                ZapiskiPanel = false;
                FileZapiski.Visibility = Visibility.Collapsed;
                if (Width == 460)
                    Width -= 60;
            }
            shirina();
            NewZaiska.Focus();
        }

        void LoadingFiles()
        {
            //Путь к файлам
            Path1 = "Cacshe//Zapiska" + IDfile + "//KehSoderj.txt";
            Path2 = "Cacshe//Zapiska" + IDfile + "//Keh.txt";
            
            //Загрузка из файлов
            if (File.Exists(Path1))
                Tb.Text = File.ReadAllText(Path1);
            if (File.Exists(Path2))
            {
                string[] f = File.ReadAllLines(Path2);
                string[] j;

                //Цветовая тема
                int i = 1;
                j = f[i].Split(new char[] { '\n' });
                btnColor = Convert.ToInt32(j[0]);
                ColorChanger();

                //Заголовок
                i = 0;
                j = f[i].Split(new char[] { '\n' });
                Title = j[0];
            }
        }

        void SavingFiles()
        {
            using (StreamWriter sw = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + "Cacshe//Zapiska" + IDfile + "//Keh.txt"))
            {
                sw.WriteLine(Title);
                sw.WriteLine(btnColor.ToString());
            }

            using (StreamWriter sw = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + "Cacshe//Zapiska" + IDfile + "//KehSoderj.txt"))
            {
                sw.WriteLine(Tb.Text);
            }
        }

        private void Item1_Selected(object sender, RoutedEventArgs e)
        {
            if(IDfile == 0)
            {
                IDfile = 1;
            }
            else
            {
                SavingFiles();
            };
            IDfile = 1;
            LoadingFiles();
        }

        private void Item2_Selected(object sender, RoutedEventArgs e)
        {
            SavingFiles();
            IDfile = 2;
            LoadingFiles();
        }

        private void Item3_Selected(object sender, RoutedEventArgs e)
        {
            SavingFiles();
            IDfile = 3;
            LoadingFiles();
        }
    }
}